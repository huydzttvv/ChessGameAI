# How to run
### Cd to ./ChessAI.py
### Run with configuration Menu (Old code)
python ChessMain.py
### Run Auto Chess with Our agent easy mode
```python
python ChessMain.py TERMINAL EASY WHITE_AGENT_OPPONENT_BLACK
```
### Run Auto Chess with Our agent MEDIUM mode
```python
python ChessMain.py TERMINAL MEDIUM WHITE_AGENT_OPPONENT_BLACK
```

### Run Auto Chess with Our agent MEDIUM mode with Our agent as black (move second)
```python
python ChessMain.py TERMINAL MEDIUM BLACK_AGENT_OPPONENT_WHITE
```

